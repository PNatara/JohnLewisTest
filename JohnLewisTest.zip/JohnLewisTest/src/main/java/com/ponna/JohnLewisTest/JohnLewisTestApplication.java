package com.ponna.JohnLewisTest;

import com.ponna.domain.Product;
import com.ponna.domain.Products;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@SpringBootApplication
public class JohnLewisTestApplication {

	private static final Logger log = LoggerFactory.getLogger("JohnLewisTestApplication.class");
	public static void main(String[] args) {
		SpringApplication.run(JohnLewisTestApplication.class, args);

		RestTemplate restTemplate = new RestTemplate();
		Map<String, String> map = new HashMap();
		map.put("labelType ","ShowWasNow");
		Products products = restTemplate.getForObject("https://jl-nonprod-syst.apigee.net/v1/categories/600001506/products?key=2ALHCAAs6ikGRBoy6eTHA58RaG097Fma", Products.class, map);
		log.info("Initial list of products:"+products.toString());

		//filtered list of product with now and was not equal to null
		List<Product> productList = products.getProducts().stream().filter(x -> x.getPrice().getNow() != null && x.getPrice().getWas() != null ).collect(Collectors.toList());

		//sorted list of values
		Collections.sort(productList, (x,y) -> {
			double nowPriceDouble = Double.parseDouble(x.getPrice().getNow());
			double wasPriceDouble = Double.parseDouble(x.getPrice().getWas());
			double v = wasPriceDouble - nowPriceDouble;
			double nowYPriceDouble = Double.parseDouble(y.getPrice().getNow());
			double wasYPriceDouble = Double.parseDouble(y.getPrice().getWas());
			double vY = wasYPriceDouble - nowYPriceDouble;
			return (int) (v -vY);
		});

		//currently empty because the condition now & was are both not null has no records
		log.info("Product Sorted Final List:"+productList.toString());
	}
}
