package com.ponna.domain;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import static com.fasterxml.jackson.databind.node.JsonNodeType.STRING;


public class PriceDeserializer extends JsonDeserializer {

    private static final Logger LOG = LoggerFactory.getLogger("JsonDeserializer.class");

    @Override
    public Price deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException, JsonProcessingException {
        JsonNode node = jsonParser.getCodec().readTree(jsonParser);

        Price price = new Price();

        try {
            String was = node.get("was") != null ? "£"+node.get("was").asText():null;

            String then1 = node.get("then1") != null ?  "£"+node.get("then1").asText() : null;
            String then2 = node.get("then2") != null ?  "£"+node.get("then2").asText() : null;
            String uom = node.get("uom").asText();
            String currency = node.get("currency").asText();

            JsonNode nd = node.get("now");
            String now = null;
            String nowPrice = null;
            String from = null;
            String to = null;
            if (nd.getNodeType().compareTo(STRING) == 0) {
                now = node.get("now").asText();
                double nowPriceDouble = Double.parseDouble(now);
                if(nowPriceDouble >= 10){
                    nowPrice = String.valueOf("£"+(int) nowPriceDouble);
                }
                else {
                    nowPrice = String.valueOf("£"+ nowPriceDouble);
                }
            }
            else {
                Iterator<Map.Entry<String, JsonNode>> it = nd.fields();

                while(it.hasNext()){
                    Map.Entry<String,JsonNode> map = it.next();
                    if(map.getKey().equalsIgnoreCase("from")) {
                        from = map.getValue() != null ? map.getValue().asText():null;
                    }else if(map.getKey().equalsIgnoreCase("to")) {
                        to = map.getValue() != null ? map.getValue().asText():null;
                    }
                }
            }
            String labelType = "ShowWasNow";
            if(labelType == null) {
                labelType = "ShowWasNow";
            }

            String labelPrice = "";
            if("ShowWasNow".equalsIgnoreCase(labelType)) {
                labelPrice = String.format("“Was %s, now %s",was,nowPrice);
            }
            else if("ShowWasThenNow".equalsIgnoreCase(labelType)) {
                if(then2 != null) {
                    labelPrice = String.format("“Was %s, then %s, now %s",was, then2, nowPrice);
                }
                else if(then1 != null) {
                    labelPrice = String.format("“Was %s, then %s, now %s",was, then1, nowPrice);
                }
                else {
                    labelPrice = String.format("“Was %s, now %s",was, nowPrice);
                }
            }
            else if("ShowPercDscount".equalsIgnoreCase(labelType)){
                //3.	ShowPercDscount  - in which case return “x% off - now £y.yy”.
                labelPrice = String.format("“x% off, now %s", nowPrice);
            }

            price.setPriceLabel(labelPrice);
            price.setNowPrice(nowPrice);
            price.setNow(now);
            price.setThen1(then1);
            price.setFrom(from);
            price.setTo(to);
            price.setThen2(then2);
            price.setUom(uom);
            price.setCurrency(currency);

        }
        catch(Exception e){
            LOG.info(e.getMessage(),e);
        }
        return price;
    }
}
