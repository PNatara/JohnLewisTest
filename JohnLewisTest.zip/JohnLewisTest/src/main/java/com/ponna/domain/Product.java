package com.ponna.domain;

import com.fasterxml.jackson.annotation.*;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@JsonIgnoreProperties
public class Product {

    private String productId;

    private String title;

    @JsonProperty("price")
    private Price price;

    private List<ColorSwatches> colorSwatches;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Price getPrice() {
        return price;
    }

    public void setPrice(Price price) {
        this.price = price;
    }



    public List<ColorSwatches> getColorSwatches() {
        return colorSwatches;
    }

    public void setColorSwatches(List<ColorSwatches> colorSwatches) {
        this.colorSwatches = colorSwatches;
    }

    @Override
    public String toString() {
        return "Product{" +
                "productId='" + productId + '\'' +
                ", title='" + title + '\'' +
                ", nowPrice=" + price.getNowPrice() +
                ", priceLabel=" + price.getPriceLabel() +
                ", colorSwatches=" + colorSwatches +
                '}';
    }
}
