package com.ponna.domain;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;

import java.awt.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ColorSwatchesDeserializer extends JsonDeserializer {

    private Map<String, Color> colorMap = new HashMap<>();

    public ColorSwatchesDeserializer(){
        colorMap.put("Wine", Color.MAGENTA);
        colorMap.put("Midnight", Color.BLACK);
        colorMap.put("French Blue", Color.BLUE);
        colorMap.put("Hibiscus", Color.YELLOW);
        colorMap.put("Ice Grey Retro Spot", Color.LIGHT_GRAY);
        colorMap.put("Washed Black", Color.BLACK);

    }
    public ColorSwatches deserialize(JsonParser jsonParser, DeserializationContext deserializationContext)
            throws IOException, JsonProcessingException {

        ColorSwatches colorSwatches = new ColorSwatches();
        ObjectCodec codec = jsonParser.getCodec();
        JsonNode node = codec.readTree(jsonParser);
        JsonNode jn = node.get("color");

        if (jn != null) {
            String color = jn.asText();
            Color c = colorMap.get(color);
            if(c == null) {
                //defaulting the color if not found
                c = colorMap.get("Hibiscus");
            }
            String hexString = Integer.toHexString(c.getRGB() & 0x00ffffff);
            colorSwatches.setRgbColor(hexString);
            colorSwatches.setColor(color);
        }
        jn = node.get("skuid");
        if (jn != null) {
            String skuid = jn.asText();
            colorSwatches.setSkuid(skuid);
        }
        return colorSwatches;
    }
}
